﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidExamTask.Employees
{
    struct Dates
    {
        private byte day;
        private byte month;
        private ushort year;

        public void BirthOfDate(byte day, byte month, ushort year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }
        public void JoiningDate(byte day, byte month, ushort year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }
        public void ShowBirthOfDate()
        {
            Console.WriteLine("Birth Date: {0}/{1}/{2}", day, month, year);
        }
        public void ShowJoiningDate()
        {
            Console.WriteLine("Join Date: {0}/{1}/{2}", day, month, year);
        }
    }

    struct EmpResidenceInfo
    {
        private string thana;
        private string homeDistrict;
        private int phoneNo;

        public void EmpInfos(string thana, string homeDistrict, int phoneNo)
        {
            this.thana = thana;
            this.homeDistrict = homeDistrict;
            this.phoneNo = phoneNo;
        }
        public void ShowEmpResidenceInfo()
        {
            Console.WriteLine("Thana: {0}", thana);
            Console.WriteLine("Home District: {0}", homeDistrict);
            Console.WriteLine("Phone: {0}", phoneNo);
        }
    }

    class Address
    {
        private Dates days;
        private EmpResidenceInfo addressInfo;

        public Address()
        {

        }
        public Address(Dates days, EmpResidenceInfo addressInfo)
        {
            this.AllDates = days;
            this.Residence = addressInfo;
        }
        public Dates AllDates
        {
            get {return this.days;}

            set {this.days = value;}
        }
        public EmpResidenceInfo Residence
        {
            get {return this.addressInfo;}

            set {this.addressInfo = value;}
        }
        public void ShowEmpInfos()
        {
            this.AllDates.ShowBirthOfDate();
            this.AllDates.ShowJoiningDate();
            this.Residence.ShowEmpResidenceInfo();
        }
    }
}
